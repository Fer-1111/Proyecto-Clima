export { PingModule } from "./ping.module";
